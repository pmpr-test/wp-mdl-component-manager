<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66eae8e89fd5e             |
    |_______________________________________|
*/
 namespace Pmpr\Module\ComponentManager\PushUpdate; use Pmpr\Common\Foundation\Interfaces\Constants; use Pmpr\Common\Foundation\Process\Queue; class Process extends Queue { const oyouaagycauaqgkc = "\x63\157\155\160\157\156\x65\x6e\164\137\155\141\156\141\x67\x65\162\x5f\x6a\x6f\142\137\160\165\163\x68\137\x75\x70\x64\141\x74\145"; public function eamuuiioigiouimg($wksoawcgagcgoask, $wqogggcaamgeiwew) : int { $ksaameoqigiaoigg = 0; if ($this->yyuksmqogammigqm($wksoawcgagcgoask)) { goto mkwkkmkgiqiamacc; } $this->ksicwcssyugsigka(time(), self::oyouaagycauaqgkc, [Constants::ocwsuwyiiasigqaa => $wksoawcgagcgoask, Constants::oyaoekcogwkcekcc => $wqogggcaamgeiwew]); mkwkkmkgiqiamacc: return $ksaameoqigiaoigg; } public function yyuksmqogammigqm($wksoawcgagcgoask) : bool { return $this->exists([self::cmooywkooekaakwk => self::oyouaagycauaqgkc, self::okeuagwgwkmiokac => [self::ocwsuwyiiasigqaa => $wksoawcgagcgoask]]); } }
