<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66eae8e89fd5e             |
    |_______________________________________|
*/
 namespace Pmpr\Module\ComponentManager\Model; use Pmpr\Module\ComponentManager\Container; class Model extends Container { public function mameiwsayuyquoeq() { Report::symcgieuakksimmu(); Request::symcgieuakksimmu(); Purchase::symcgieuakksimmu(); Component::symcgieuakksimmu(); Campaign::symcgieuakksimmu(); Installation::symcgieuakksimmu(); } }
