<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66e5e7901da8d             |
    |_______________________________________|
*/
 namespace Pmpr\Module\ComponentManager\Frontend; use Pmpr\Module\ComponentManager\Container; abstract class Common extends Container { }
