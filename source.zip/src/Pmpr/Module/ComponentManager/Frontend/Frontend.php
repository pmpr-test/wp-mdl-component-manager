<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66eae8e89fd5e             |
    |_______________________________________|
*/
 namespace Pmpr\Module\ComponentManager\Frontend; class Frontend extends Common { }
