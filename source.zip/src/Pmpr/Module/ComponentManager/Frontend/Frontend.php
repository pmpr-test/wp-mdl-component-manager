<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66e5ec56484aa             |
    |_______________________________________|
*/
 namespace Pmpr\Module\ComponentManager\Frontend; class Frontend extends Common { }
