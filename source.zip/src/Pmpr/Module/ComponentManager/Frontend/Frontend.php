<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670517593ad7e             |
    |_______________________________________|
*/
 namespace Pmpr\Module\ComponentManager\Frontend; class Frontend extends Common { }
