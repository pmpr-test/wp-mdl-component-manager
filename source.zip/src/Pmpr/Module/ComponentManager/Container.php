<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66eae8e89fd5e             |
    |_______________________________________|
*/
 namespace Pmpr\Module\ComponentManager; use Pmpr\Common\Foundation\Container\Container as BaseClass; abstract class Container extends BaseClass { const ieicsweaowmycywa = "\x63\x6f\x6d\160\157\x6e\x65\156\164\137\x6d\141\156\141\147\145\x72\137"; public function __construct() { $this->settingObj = Setting::symcgieuakksimmu(); parent::__construct(); } }
