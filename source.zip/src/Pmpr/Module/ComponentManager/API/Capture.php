<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670da318acac6             |
    |_______________________________________|
*/
 namespace Pmpr\Module\ComponentManager\API; use Pmpr\Common\Foundation\API\API; class Capture extends API { public function __construct() { $this->domain = "\x68\x74\164\160\163\x3a\57\57\141\160\x69\x2e\164\150\x75\x6d\142\x6e\141\x69\x6c\x2e\x77\163\x2f\141\x70\x69\57\141\x62\x66\x32\x38\x35\66\141\67\x63\70\x30\x64\60\61\145\142\x33\60\x64\x62\144\65\x30\142\67\64\67\x32\x63\145\65\x66\63\144\61\70\60\x39\60\70\64\60\142"; parent::__construct(); } public function qikaamumksmwoeqi($eeamcawaiqocomwy, $qeswwaqqsyymqawg = 800) { $eeamcawaiqocomwy = esc_url($eeamcawaiqocomwy); $aqykuigiuwmmcieu = false; $keccaugmemegoimu = $this->get("\x2f\x74\x68\165\155\142\156\x61\151\154\x2f\147\x65\164\77\x75\162\154\x3d{$eeamcawaiqocomwy}\46\167\x69\x64\164\x68\x3d{$qeswwaqqsyymqawg}"); if ($this->occymigcemkqucuw($keccaugmemegoimu, $uamcoiueqaamsqma)) { $aqykuigiuwmmcieu = $this->caokeucsksukesyo()->owgcciayoweymuws()->uiyouwwuscecumsg($this->saegmcouuukeykgi($keccaugmemegoimu), "\x69\x6d\x61\x67\x65\x2f\152\160\x67"); } return $aqykuigiuwmmcieu; } }
