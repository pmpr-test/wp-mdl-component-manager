<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             675f1d1141a85             |
    |_______________________________________|
*/
 namespace Pmpr\Module\ComponentManager\API; use Pmpr\Common\Foundation\API\API; class Capture extends API { public function __construct() { $this->domain = "\150\x74\164\x70\163\x3a\x2f\x2f\141\x70\x69\56\x74\x68\165\155\142\156\x61\151\x6c\x2e\167\163\x2f\141\x70\x69\x2f\x61\142\146\62\x38\x35\66\141\x37\143\x38\x30\x64\x30\61\145\x62\63\x30\x64\142\x64\65\x30\142\x37\64\67\x32\x63\x65\x35\146\x33\144\x31\70\60\71\60\70\64\x30\142"; parent::__construct(); } public function qikaamumksmwoeqi($eeamcawaiqocomwy, $qeswwaqqsyymqawg = 800) { $eeamcawaiqocomwy = esc_url($eeamcawaiqocomwy); $aqykuigiuwmmcieu = false; $keccaugmemegoimu = $this->get("\x2f\x74\x68\165\155\142\156\x61\x69\154\x2f\147\145\164\77\165\x72\x6c\x3d{$eeamcawaiqocomwy}\46\167\x69\x64\x74\x68\75{$qeswwaqqsyymqawg}"); if ($this->occymigcemkqucuw($keccaugmemegoimu, $uamcoiueqaamsqma)) { $aqykuigiuwmmcieu = $this->caokeucsksukesyo()->owgcciayoweymuws()->uiyouwwuscecumsg($this->saegmcouuukeykgi($keccaugmemegoimu), "\151\x6d\x61\x67\x65\57\152\160\x67"); } return $aqykuigiuwmmcieu; } }
