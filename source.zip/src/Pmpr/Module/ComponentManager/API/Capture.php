<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             672f20b43fd94             |
    |_______________________________________|
*/
 namespace Pmpr\Module\ComponentManager\API; use Pmpr\Common\Foundation\API\API; class Capture extends API { public function __construct() { $this->domain = "\x68\164\164\160\163\x3a\x2f\x2f\x61\160\151\56\164\x68\x75\x6d\142\156\141\x69\x6c\x2e\x77\x73\x2f\141\x70\x69\x2f\141\x62\x66\x32\x38\x35\66\141\67\x63\70\x30\x64\60\61\145\142\x33\60\x64\x62\x64\x35\60\142\67\64\x37\x32\143\x65\x35\146\x33\x64\61\x38\60\71\x30\70\x34\60\142"; parent::__construct(); } public function qikaamumksmwoeqi($eeamcawaiqocomwy, $qeswwaqqsyymqawg = 800) { $eeamcawaiqocomwy = esc_url($eeamcawaiqocomwy); $aqykuigiuwmmcieu = false; $keccaugmemegoimu = $this->get("\57\164\x68\x75\x6d\x62\156\141\x69\x6c\57\147\x65\164\x3f\x75\x72\154\x3d{$eeamcawaiqocomwy}\x26\x77\151\x64\x74\x68\75{$qeswwaqqsyymqawg}"); if ($this->occymigcemkqucuw($keccaugmemegoimu, $uamcoiueqaamsqma)) { $aqykuigiuwmmcieu = $this->caokeucsksukesyo()->owgcciayoweymuws()->uiyouwwuscecumsg($this->saegmcouuukeykgi($keccaugmemegoimu), "\151\x6d\x61\x67\x65\x2f\x6a\160\147"); } return $aqykuigiuwmmcieu; } }
