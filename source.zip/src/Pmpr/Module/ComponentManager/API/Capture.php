<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670d3642218a3             |
    |_______________________________________|
*/
 namespace Pmpr\Module\ComponentManager\API; use Pmpr\Common\Foundation\API\API; class Capture extends API { public function __construct() { $this->domain = "\150\164\x74\160\x73\72\x2f\x2f\x61\x70\151\56\164\150\x75\155\x62\156\141\151\154\56\x77\163\x2f\x61\160\x69\x2f\x61\x62\x66\62\x38\65\x36\141\x37\143\70\x30\x64\60\x31\x65\x62\63\60\x64\142\144\x35\60\142\x37\64\x37\62\x63\145\x35\x66\x33\x64\x31\x38\60\x39\x30\x38\x34\x30\142"; parent::__construct(); } public function qikaamumksmwoeqi($eeamcawaiqocomwy, $qeswwaqqsyymqawg = 800) { $eeamcawaiqocomwy = esc_url($eeamcawaiqocomwy); $aqykuigiuwmmcieu = false; $keccaugmemegoimu = $this->get("\x2f\x74\x68\165\x6d\x62\156\141\x69\154\x2f\x67\145\x74\x3f\165\162\154\x3d{$eeamcawaiqocomwy}\x26\x77\151\x64\164\x68\x3d{$qeswwaqqsyymqawg}"); if ($this->occymigcemkqucuw($keccaugmemegoimu, $uamcoiueqaamsqma)) { $aqykuigiuwmmcieu = $this->caokeucsksukesyo()->owgcciayoweymuws()->uiyouwwuscecumsg($this->saegmcouuukeykgi($keccaugmemegoimu), "\151\x6d\x61\147\x65\57\x6a\160\147"); } return $aqykuigiuwmmcieu; } }
