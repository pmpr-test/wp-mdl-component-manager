<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6720b717ce967             |
    |_______________________________________|
*/
 namespace Pmpr\Module\ComponentManager\API; use Pmpr\Common\Foundation\API\API; class Capture extends API { public function __construct() { $this->domain = "\150\164\x74\x70\x73\x3a\x2f\x2f\141\x70\x69\x2e\x74\150\x75\x6d\142\x6e\x61\151\154\56\x77\163\x2f\141\160\151\x2f\141\142\x66\x32\x38\x35\66\141\67\143\x38\x30\x64\60\x31\x65\x62\x33\60\144\x62\144\65\60\142\67\64\x37\62\143\145\x35\x66\63\144\x31\x38\x30\71\x30\x38\64\60\x62"; parent::__construct(); } public function qikaamumksmwoeqi($eeamcawaiqocomwy, $qeswwaqqsyymqawg = 800) { $eeamcawaiqocomwy = esc_url($eeamcawaiqocomwy); $aqykuigiuwmmcieu = false; $keccaugmemegoimu = $this->get("\x2f\x74\150\165\x6d\142\156\141\x69\154\57\147\x65\164\x3f\x75\162\154\75{$eeamcawaiqocomwy}\x26\x77\151\x64\x74\x68\x3d{$qeswwaqqsyymqawg}"); if ($this->occymigcemkqucuw($keccaugmemegoimu, $uamcoiueqaamsqma)) { $aqykuigiuwmmcieu = $this->caokeucsksukesyo()->owgcciayoweymuws()->uiyouwwuscecumsg($this->saegmcouuukeykgi($keccaugmemegoimu), "\x69\x6d\x61\147\145\x2f\152\160\147"); } return $aqykuigiuwmmcieu; } }
