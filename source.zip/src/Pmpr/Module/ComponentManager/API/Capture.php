<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6720b58d5f663             |
    |_______________________________________|
*/
 namespace Pmpr\Module\ComponentManager\API; use Pmpr\Common\Foundation\API\API; class Capture extends API { public function __construct() { $this->domain = "\x68\x74\x74\x70\163\x3a\x2f\57\x61\160\x69\56\164\150\165\x6d\142\156\x61\x69\x6c\x2e\167\163\57\141\160\151\x2f\x61\142\x66\x32\x38\65\x36\x61\67\143\x38\60\x64\60\61\x65\142\63\60\x64\142\x64\65\60\142\x37\x34\67\x32\x63\x65\x35\146\x33\144\61\70\x30\x39\60\70\64\60\142"; parent::__construct(); } public function qikaamumksmwoeqi($eeamcawaiqocomwy, $qeswwaqqsyymqawg = 800) { $eeamcawaiqocomwy = esc_url($eeamcawaiqocomwy); $aqykuigiuwmmcieu = false; $keccaugmemegoimu = $this->get("\x2f\x74\150\x75\155\142\156\141\151\x6c\x2f\147\x65\x74\77\165\162\154\x3d{$eeamcawaiqocomwy}\x26\167\x69\144\164\150\75{$qeswwaqqsyymqawg}"); if ($this->occymigcemkqucuw($keccaugmemegoimu, $uamcoiueqaamsqma)) { $aqykuigiuwmmcieu = $this->caokeucsksukesyo()->owgcciayoweymuws()->uiyouwwuscecumsg($this->saegmcouuukeykgi($keccaugmemegoimu), "\x69\x6d\141\x67\x65\x2f\x6a\x70\147"); } return $aqykuigiuwmmcieu; } }
