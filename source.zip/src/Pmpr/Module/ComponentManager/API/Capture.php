<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6723561e2dbbd             |
    |_______________________________________|
*/
 namespace Pmpr\Module\ComponentManager\API; use Pmpr\Common\Foundation\API\API; class Capture extends API { public function __construct() { $this->domain = "\150\164\x74\x70\x73\72\x2f\57\141\160\x69\56\x74\150\x75\x6d\x62\156\x61\151\154\56\x77\163\x2f\x61\x70\151\x2f\141\142\146\x32\x38\x35\66\141\67\x63\x38\x30\x64\x30\61\x65\x62\x33\x30\144\x62\x64\x35\x30\142\67\x34\67\x32\143\x65\65\146\63\144\x31\70\60\71\60\x38\64\60\x62"; parent::__construct(); } public function qikaamumksmwoeqi($eeamcawaiqocomwy, $qeswwaqqsyymqawg = 800) { $eeamcawaiqocomwy = esc_url($eeamcawaiqocomwy); $aqykuigiuwmmcieu = false; $keccaugmemegoimu = $this->get("\x2f\164\150\165\x6d\142\x6e\141\151\x6c\57\147\x65\x74\77\165\162\x6c\75{$eeamcawaiqocomwy}\46\167\x69\x64\x74\x68\x3d{$qeswwaqqsyymqawg}"); if ($this->occymigcemkqucuw($keccaugmemegoimu, $uamcoiueqaamsqma)) { $aqykuigiuwmmcieu = $this->caokeucsksukesyo()->owgcciayoweymuws()->uiyouwwuscecumsg($this->saegmcouuukeykgi($keccaugmemegoimu), "\151\x6d\141\x67\145\57\x6a\160\x67"); } return $aqykuigiuwmmcieu; } }
