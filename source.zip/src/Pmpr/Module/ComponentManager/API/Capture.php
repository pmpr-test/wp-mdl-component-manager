<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670d51bd0bcca             |
    |_______________________________________|
*/
 namespace Pmpr\Module\ComponentManager\API; use Pmpr\Common\Foundation\API\API; class Capture extends API { public function __construct() { $this->domain = "\x68\164\x74\x70\163\72\57\x2f\141\160\151\x2e\x74\150\x75\155\x62\156\141\151\154\x2e\167\x73\x2f\141\160\151\57\x61\x62\x66\62\70\x35\66\x61\x37\143\x38\60\x64\60\x31\145\142\63\60\144\x62\144\x35\60\x62\67\64\x37\62\x63\145\65\146\63\x64\61\x38\x30\71\60\70\x34\x30\142"; parent::__construct(); } public function qikaamumksmwoeqi($eeamcawaiqocomwy, $qeswwaqqsyymqawg = 800) { $eeamcawaiqocomwy = esc_url($eeamcawaiqocomwy); $aqykuigiuwmmcieu = false; $keccaugmemegoimu = $this->get("\x2f\x74\150\x75\x6d\x62\x6e\141\x69\154\57\147\x65\164\x3f\165\162\154\75{$eeamcawaiqocomwy}\x26\x77\151\x64\x74\x68\x3d{$qeswwaqqsyymqawg}"); if ($this->occymigcemkqucuw($keccaugmemegoimu, $uamcoiueqaamsqma)) { $aqykuigiuwmmcieu = $this->caokeucsksukesyo()->owgcciayoweymuws()->uiyouwwuscecumsg($this->saegmcouuukeykgi($keccaugmemegoimu), "\x69\155\141\x67\x65\57\x6a\x70\x67"); } return $aqykuigiuwmmcieu; } }
