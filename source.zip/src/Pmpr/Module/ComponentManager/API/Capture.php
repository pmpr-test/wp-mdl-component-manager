<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             67705d837fe34             |
    |_______________________________________|
*/
 namespace Pmpr\Module\ComponentManager\API; use Pmpr\Common\Foundation\API\API; class Capture extends API { public function __construct() { $this->domain = "\x68\x74\164\x70\163\x3a\x2f\57\x61\x70\x69\x2e\x74\x68\165\x6d\x62\x6e\141\151\x6c\56\x77\x73\x2f\x61\x70\151\57\x61\x62\x66\x32\70\65\66\141\x37\x63\70\60\x64\60\61\x65\x62\63\x30\144\x62\144\65\x30\x62\67\64\67\x32\143\x65\65\146\63\x64\x31\70\60\71\x30\70\x34\60\x62"; parent::__construct(); } public function qikaamumksmwoeqi($eeamcawaiqocomwy, $qeswwaqqsyymqawg = 800) { $eeamcawaiqocomwy = esc_url($eeamcawaiqocomwy); $aqykuigiuwmmcieu = false; $keccaugmemegoimu = $this->get("\57\x74\150\x75\x6d\x62\x6e\141\x69\154\57\147\145\x74\x3f\x75\162\x6c\x3d{$eeamcawaiqocomwy}\x26\167\x69\144\164\x68\75{$qeswwaqqsyymqawg}"); if ($this->occymigcemkqucuw($keccaugmemegoimu, $uamcoiueqaamsqma)) { $aqykuigiuwmmcieu = $this->caokeucsksukesyo()->owgcciayoweymuws()->uiyouwwuscecumsg($this->saegmcouuukeykgi($keccaugmemegoimu), "\x69\155\141\x67\145\x2f\x6a\160\x67"); } return $aqykuigiuwmmcieu; } }
