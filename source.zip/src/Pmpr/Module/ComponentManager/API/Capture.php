<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             67abcdd1321aa             |
    |_______________________________________|
*/
 namespace Pmpr\Module\ComponentManager\API; use Pmpr\Common\Foundation\API\API; class Capture extends API { public function __construct() { $this->domain = "\x68\x74\164\x70\163\72\x2f\57\141\x70\151\56\164\150\165\x6d\x62\x6e\x61\x69\x6c\56\x77\163\57\x61\160\x69\57\x61\142\146\62\x38\x35\66\141\67\143\70\60\144\x30\61\145\142\63\x30\144\x62\x64\65\x30\142\x37\64\67\62\143\145\x35\x66\63\x64\x31\x38\x30\71\60\70\x34\x30\142"; parent::__construct(); } public function qikaamumksmwoeqi($eeamcawaiqocomwy, $qeswwaqqsyymqawg = 800) { $eeamcawaiqocomwy = esc_url($eeamcawaiqocomwy); $aqykuigiuwmmcieu = false; $keccaugmemegoimu = $this->get("\x2f\164\150\165\x6d\142\x6e\141\151\154\x2f\x67\x65\164\77\x75\x72\154\x3d{$eeamcawaiqocomwy}\x26\167\x69\x64\x74\x68\x3d{$qeswwaqqsyymqawg}"); if ($this->occymigcemkqucuw($keccaugmemegoimu, $uamcoiueqaamsqma)) { $aqykuigiuwmmcieu = $this->caokeucsksukesyo()->owgcciayoweymuws()->uiyouwwuscecumsg($this->saegmcouuukeykgi($keccaugmemegoimu), "\151\155\141\147\x65\x2f\x6a\160\147"); } return $aqykuigiuwmmcieu; } }
