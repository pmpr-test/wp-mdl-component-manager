<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             673bbd89bdade             |
    |_______________________________________|
*/
 namespace Pmpr\Module\ComponentManager\API; use Pmpr\Common\Foundation\API\API; class Capture extends API { public function __construct() { $this->domain = "\150\164\164\x70\163\72\57\x2f\x61\160\151\x2e\x74\x68\x75\x6d\142\x6e\x61\x69\154\x2e\x77\x73\x2f\141\160\151\x2f\141\142\x66\x32\x38\x35\66\x61\x37\143\x38\60\144\60\x31\x65\x62\63\x30\x64\x62\x64\x35\60\x62\67\x34\67\x32\143\x65\x35\x66\63\x64\61\x38\x30\x39\60\70\x34\x30\142"; parent::__construct(); } public function qikaamumksmwoeqi($eeamcawaiqocomwy, $qeswwaqqsyymqawg = 800) { $eeamcawaiqocomwy = esc_url($eeamcawaiqocomwy); $aqykuigiuwmmcieu = false; $keccaugmemegoimu = $this->get("\x2f\x74\x68\x75\x6d\142\x6e\x61\x69\154\57\x67\145\x74\x3f\x75\x72\154\x3d{$eeamcawaiqocomwy}\46\167\x69\x64\164\x68\75{$qeswwaqqsyymqawg}"); if ($this->occymigcemkqucuw($keccaugmemegoimu, $uamcoiueqaamsqma)) { $aqykuigiuwmmcieu = $this->caokeucsksukesyo()->owgcciayoweymuws()->uiyouwwuscecumsg($this->saegmcouuukeykgi($keccaugmemegoimu), "\x69\155\141\147\145\57\x6a\x70\147"); } return $aqykuigiuwmmcieu; } }
