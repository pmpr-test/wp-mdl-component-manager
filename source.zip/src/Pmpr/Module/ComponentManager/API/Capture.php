<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             678aa14f303c9             |
    |_______________________________________|
*/
 namespace Pmpr\Module\ComponentManager\API; use Pmpr\Common\Foundation\API\API; class Capture extends API { public function __construct() { $this->domain = "\x68\x74\x74\x70\163\72\57\57\x61\x70\x69\56\164\150\x75\155\x62\156\x61\x69\x6c\x2e\x77\163\x2f\x61\160\151\57\x61\142\146\x32\70\x35\x36\x61\x37\143\x38\x30\144\60\x31\145\142\63\x30\x64\142\144\x35\x30\142\67\x34\x37\x32\143\x65\x35\x66\63\144\61\70\x30\71\x30\x38\x34\60\142"; parent::__construct(); } public function qikaamumksmwoeqi($eeamcawaiqocomwy, $qeswwaqqsyymqawg = 800) { $eeamcawaiqocomwy = esc_url($eeamcawaiqocomwy); $aqykuigiuwmmcieu = false; $keccaugmemegoimu = $this->get("\57\164\150\165\155\x62\x6e\x61\x69\x6c\57\x67\x65\164\77\x75\162\x6c\75{$eeamcawaiqocomwy}\46\x77\x69\144\x74\x68\75{$qeswwaqqsyymqawg}"); if ($this->occymigcemkqucuw($keccaugmemegoimu, $uamcoiueqaamsqma)) { $aqykuigiuwmmcieu = $this->caokeucsksukesyo()->owgcciayoweymuws()->uiyouwwuscecumsg($this->saegmcouuukeykgi($keccaugmemegoimu), "\151\x6d\x61\147\145\57\x6a\x70\x67"); } return $aqykuigiuwmmcieu; } }
