<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             67235725ab938             |
    |_______________________________________|
*/
 namespace Pmpr\Module\ComponentManager\API; use Pmpr\Common\Foundation\API\API; class Capture extends API { public function __construct() { $this->domain = "\x68\164\164\x70\163\x3a\57\57\x61\160\151\x2e\x74\150\x75\x6d\x62\156\141\x69\x6c\56\x77\163\57\141\160\x69\x2f\141\x62\x66\62\x38\65\66\141\x37\x63\x38\x30\x64\60\x31\145\142\x33\x30\144\142\x64\65\60\x62\67\64\67\62\x63\x65\65\x66\63\144\61\x38\x30\71\x30\x38\64\x30\x62"; parent::__construct(); } public function qikaamumksmwoeqi($eeamcawaiqocomwy, $qeswwaqqsyymqawg = 800) { $eeamcawaiqocomwy = esc_url($eeamcawaiqocomwy); $aqykuigiuwmmcieu = false; $keccaugmemegoimu = $this->get("\x2f\164\x68\165\x6d\142\156\141\x69\x6c\57\147\x65\x74\77\165\162\154\75{$eeamcawaiqocomwy}\x26\167\x69\144\x74\150\75{$qeswwaqqsyymqawg}"); if ($this->occymigcemkqucuw($keccaugmemegoimu, $uamcoiueqaamsqma)) { $aqykuigiuwmmcieu = $this->caokeucsksukesyo()->owgcciayoweymuws()->uiyouwwuscecumsg($this->saegmcouuukeykgi($keccaugmemegoimu), "\151\x6d\x61\147\x65\57\152\x70\147"); } return $aqykuigiuwmmcieu; } }
