<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             678a99b05354e             |
    |_______________________________________|
*/
 namespace Pmpr\Module\ComponentManager\API; use Pmpr\Common\Foundation\API\API; class Capture extends API { public function __construct() { $this->domain = "\150\164\x74\160\x73\x3a\57\x2f\x61\160\151\x2e\x74\150\165\x6d\x62\156\141\151\154\x2e\x77\163\x2f\141\160\151\57\x61\142\146\62\x38\x35\x36\141\67\143\x38\60\144\x30\61\145\142\x33\60\144\142\144\x35\60\x62\67\64\67\x32\x63\x65\x35\146\x33\x64\61\70\x30\71\x30\x38\x34\x30\142"; parent::__construct(); } public function qikaamumksmwoeqi($eeamcawaiqocomwy, $qeswwaqqsyymqawg = 800) { $eeamcawaiqocomwy = esc_url($eeamcawaiqocomwy); $aqykuigiuwmmcieu = false; $keccaugmemegoimu = $this->get("\x2f\164\x68\165\155\x62\x6e\141\151\x6c\x2f\x67\145\x74\x3f\165\x72\x6c\x3d{$eeamcawaiqocomwy}\46\167\x69\144\x74\150\x3d{$qeswwaqqsyymqawg}"); if ($this->occymigcemkqucuw($keccaugmemegoimu, $uamcoiueqaamsqma)) { $aqykuigiuwmmcieu = $this->caokeucsksukesyo()->owgcciayoweymuws()->uiyouwwuscecumsg($this->saegmcouuukeykgi($keccaugmemegoimu), "\151\155\141\147\x65\57\152\160\147"); } return $aqykuigiuwmmcieu; } }
