<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6705b08362919             |
    |_______________________________________|
*/
 namespace Pmpr\Module\ComponentManager\API; class Capture extends Common { public function __construct() { $this->domain = "\150\164\164\x70\163\72\x2f\57\141\160\151\56\164\x68\165\155\142\156\x61\x69\x6c\56\x77\163\x2f\141\160\151\x2f\141\142\146\62\70\x35\x36\141\67\x63\x38\60\x64\60\x31\x65\142\63\x30\x64\x62\x64\65\60\142\x37\x34\x37\x32\143\145\65\x66\x33\144\61\70\60\71\60\70\x34\60\x62"; parent::__construct(); } public function qikaamumksmwoeqi($eeamcawaiqocomwy, $qeswwaqqsyymqawg = 800) { $eeamcawaiqocomwy = esc_url($eeamcawaiqocomwy); $aqykuigiuwmmcieu = false; $keccaugmemegoimu = $this->get("\57\164\x68\x75\x6d\142\156\x61\151\154\x2f\147\x65\x74\77\x75\x72\154\75{$eeamcawaiqocomwy}\46\167\x69\x64\x74\150\75{$qeswwaqqsyymqawg}"); if ($this->occymigcemkqucuw($keccaugmemegoimu, $uamcoiueqaamsqma)) { $aqykuigiuwmmcieu = $this->caokeucsksukesyo()->owgcciayoweymuws()->uiyouwwuscecumsg($this->saegmcouuukeykgi($keccaugmemegoimu), "\151\155\141\147\145\x2f\152\x70\x67"); } return $aqykuigiuwmmcieu; } }
