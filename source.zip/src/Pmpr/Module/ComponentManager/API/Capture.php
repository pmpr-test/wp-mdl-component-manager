<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670517593ad7e             |
    |_______________________________________|
*/
 namespace Pmpr\Module\ComponentManager\API; class Capture extends Common { public function __construct() { $this->domain = "\150\x74\164\x70\163\x3a\57\x2f\141\x70\x69\x2e\x74\x68\165\x6d\x62\156\141\151\x6c\56\x77\163\57\x61\160\151\x2f\141\x62\x66\62\x38\65\66\x61\x37\143\70\x30\x64\60\61\x65\142\63\60\144\142\x64\65\60\142\x37\64\67\x32\x63\x65\x35\146\63\x64\61\70\60\71\60\70\64\60\x62"; parent::__construct(); } public function qikaamumksmwoeqi($eeamcawaiqocomwy, $qeswwaqqsyymqawg = 800) { $eeamcawaiqocomwy = esc_url($eeamcawaiqocomwy); $aqykuigiuwmmcieu = false; $keccaugmemegoimu = $this->get("\x2f\164\x68\x75\x6d\x62\156\x61\151\x6c\57\147\145\x74\x3f\165\x72\154\75{$eeamcawaiqocomwy}\46\x77\x69\144\164\150\75{$qeswwaqqsyymqawg}"); if (!$this->occymigcemkqucuw($keccaugmemegoimu, $uamcoiueqaamsqma)) { goto kciouyuaqkyqomam; } $aqykuigiuwmmcieu = $this->caokeucsksukesyo()->owgcciayoweymuws()->uiyouwwuscecumsg($this->saegmcouuukeykgi($keccaugmemegoimu), "\x69\155\x61\147\x65\x2f\x6a\160\x67"); kciouyuaqkyqomam: return $aqykuigiuwmmcieu; } }
