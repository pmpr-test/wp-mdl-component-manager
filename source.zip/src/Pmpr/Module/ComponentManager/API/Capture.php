<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66e5e7901da8d             |
    |_______________________________________|
*/
 namespace Pmpr\Module\ComponentManager\API; class Capture extends Common { public function __construct() { $this->domain = "\x68\x74\164\160\163\72\x2f\57\141\x70\x69\56\164\150\165\155\142\156\x61\151\x6c\x2e\x77\163\57\x61\160\151\57\x61\x62\146\x32\x38\x35\66\x61\67\143\x38\x30\144\60\x31\x65\x62\63\60\x64\x62\x64\x35\x30\142\x37\x34\67\x32\x63\145\x35\146\x33\x64\x31\x38\60\x39\60\x38\64\60\x62"; parent::__construct(); } public function qikaamumksmwoeqi($eeamcawaiqocomwy, $qeswwaqqsyymqawg = 800) { $eeamcawaiqocomwy = esc_url($eeamcawaiqocomwy); $aqykuigiuwmmcieu = false; $keccaugmemegoimu = $this->get("\57\164\150\x75\155\142\156\x61\x69\x6c\x2f\x67\x65\x74\x3f\x75\162\x6c\75{$eeamcawaiqocomwy}\x26\167\151\144\x74\150\75{$qeswwaqqsyymqawg}"); if (!$this->occymigcemkqucuw($keccaugmemegoimu, $uamcoiueqaamsqma)) { goto kosaqwikueyksqmw; } $aqykuigiuwmmcieu = $this->caokeucsksukesyo()->owgcciayoweymuws()->uiyouwwuscecumsg($this->saegmcouuukeykgi($keccaugmemegoimu), "\151\155\141\x67\x65\57\152\x70\147"); kosaqwikueyksqmw: return $aqykuigiuwmmcieu; } }
