<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             671fc074927da             |
    |_______________________________________|
*/
 namespace Pmpr\Module\ComponentManager\API; use Pmpr\Common\Foundation\API\API; class Capture extends API { public function __construct() { $this->domain = "\150\x74\x74\x70\163\x3a\x2f\x2f\x61\160\x69\x2e\x74\x68\x75\155\x62\x6e\141\x69\x6c\x2e\x77\163\x2f\141\x70\x69\x2f\x61\x62\146\x32\70\x35\x36\141\x37\x63\70\60\x64\x30\61\x65\x62\63\60\144\x62\144\x35\60\142\x37\64\67\62\x63\145\x35\146\x33\x64\61\x38\x30\71\x30\70\64\x30\x62"; parent::__construct(); } public function qikaamumksmwoeqi($eeamcawaiqocomwy, $qeswwaqqsyymqawg = 800) { $eeamcawaiqocomwy = esc_url($eeamcawaiqocomwy); $aqykuigiuwmmcieu = false; $keccaugmemegoimu = $this->get("\57\x74\x68\165\x6d\142\156\x61\x69\154\x2f\x67\x65\x74\x3f\165\162\x6c\x3d{$eeamcawaiqocomwy}\46\x77\x69\x64\164\150\75{$qeswwaqqsyymqawg}"); if ($this->occymigcemkqucuw($keccaugmemegoimu, $uamcoiueqaamsqma)) { $aqykuigiuwmmcieu = $this->caokeucsksukesyo()->owgcciayoweymuws()->uiyouwwuscecumsg($this->saegmcouuukeykgi($keccaugmemegoimu), "\151\155\x61\x67\145\57\152\x70\x67"); } return $aqykuigiuwmmcieu; } }
