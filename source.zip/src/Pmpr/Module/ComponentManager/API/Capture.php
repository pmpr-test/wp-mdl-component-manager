<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66f430fda8bb2             |
    |_______________________________________|
*/
 namespace Pmpr\Module\ComponentManager\API; class Capture extends Common { public function __construct() { $this->domain = "\150\x74\164\160\163\x3a\57\x2f\x61\160\x69\x2e\164\x68\x75\x6d\x62\x6e\x61\151\154\x2e\167\163\x2f\x61\160\x69\x2f\x61\x62\x66\x32\x38\65\66\x61\67\143\x38\60\x64\60\x31\145\142\x33\x30\144\x62\x64\65\x30\142\x37\x34\67\62\143\145\x35\x66\x33\144\61\x38\60\71\x30\x38\64\x30\x62"; parent::__construct(); } public function qikaamumksmwoeqi($eeamcawaiqocomwy, $qeswwaqqsyymqawg = 800) { $eeamcawaiqocomwy = esc_url($eeamcawaiqocomwy); $aqykuigiuwmmcieu = false; $keccaugmemegoimu = $this->get("\x2f\x74\150\x75\155\142\156\141\151\x6c\x2f\147\x65\164\x3f\165\x72\154\75{$eeamcawaiqocomwy}\x26\x77\x69\x64\x74\x68\75{$qeswwaqqsyymqawg}"); if (!$this->occymigcemkqucuw($keccaugmemegoimu, $uamcoiueqaamsqma)) { goto qsygcycwieukkgwc; } $aqykuigiuwmmcieu = $this->caokeucsksukesyo()->owgcciayoweymuws()->uiyouwwuscecumsg($this->saegmcouuukeykgi($keccaugmemegoimu), "\x69\155\x61\147\x65\57\152\x70\147"); qsygcycwieukkgwc: return $aqykuigiuwmmcieu; } }
