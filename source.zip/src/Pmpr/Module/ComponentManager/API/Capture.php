<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670d00126a7de             |
    |_______________________________________|
*/
 namespace Pmpr\Module\ComponentManager\API; use Pmpr\Common\Foundation\API\API; class Capture extends API { public function __construct() { $this->domain = "\x68\x74\x74\x70\163\72\x2f\57\141\x70\151\x2e\164\150\x75\155\x62\x6e\x61\x69\154\x2e\x77\163\x2f\141\x70\151\57\141\142\146\62\70\65\x36\141\67\x63\x38\60\144\x30\x31\x65\142\63\x30\x64\x62\x64\65\60\x62\67\64\x37\x32\x63\x65\65\x66\x33\144\x31\70\60\x39\60\70\x34\x30\x62"; parent::__construct(); } public function qikaamumksmwoeqi($eeamcawaiqocomwy, $qeswwaqqsyymqawg = 800) { $eeamcawaiqocomwy = esc_url($eeamcawaiqocomwy); $aqykuigiuwmmcieu = false; $keccaugmemegoimu = $this->get("\57\x74\x68\x75\x6d\x62\156\141\x69\x6c\x2f\x67\145\x74\x3f\x75\162\154\75{$eeamcawaiqocomwy}\x26\167\x69\x64\x74\x68\75{$qeswwaqqsyymqawg}"); if ($this->occymigcemkqucuw($keccaugmemegoimu, $uamcoiueqaamsqma)) { $aqykuigiuwmmcieu = $this->caokeucsksukesyo()->owgcciayoweymuws()->uiyouwwuscecumsg($this->saegmcouuukeykgi($keccaugmemegoimu), "\151\155\141\x67\145\57\x6a\160\x67"); } return $aqykuigiuwmmcieu; } }
