<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670d46b952390             |
    |_______________________________________|
*/
 namespace Pmpr\Module\ComponentManager\API; use Pmpr\Common\Foundation\API\API; class Capture extends API { public function __construct() { $this->domain = "\150\164\164\x70\x73\x3a\57\57\x61\160\x69\x2e\164\x68\165\155\142\x6e\141\x69\154\56\x77\x73\x2f\x61\160\151\57\x61\x62\146\62\x38\x35\x36\141\x37\x63\x38\x30\x64\x30\61\145\142\63\60\144\x62\x64\x35\x30\x62\67\x34\67\x32\x63\x65\x35\146\x33\144\x31\x38\x30\x39\x30\70\64\x30\x62"; parent::__construct(); } public function qikaamumksmwoeqi($eeamcawaiqocomwy, $qeswwaqqsyymqawg = 800) { $eeamcawaiqocomwy = esc_url($eeamcawaiqocomwy); $aqykuigiuwmmcieu = false; $keccaugmemegoimu = $this->get("\x2f\x74\150\165\x6d\x62\x6e\141\151\154\x2f\x67\x65\x74\77\165\x72\x6c\75{$eeamcawaiqocomwy}\x26\167\151\x64\x74\x68\x3d{$qeswwaqqsyymqawg}"); if ($this->occymigcemkqucuw($keccaugmemegoimu, $uamcoiueqaamsqma)) { $aqykuigiuwmmcieu = $this->caokeucsksukesyo()->owgcciayoweymuws()->uiyouwwuscecumsg($this->saegmcouuukeykgi($keccaugmemegoimu), "\151\155\x61\147\x65\x2f\152\160\147"); } return $aqykuigiuwmmcieu; } }
