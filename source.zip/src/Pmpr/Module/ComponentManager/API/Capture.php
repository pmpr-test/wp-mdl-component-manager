<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670d89ed6e685             |
    |_______________________________________|
*/
 namespace Pmpr\Module\ComponentManager\API; use Pmpr\Common\Foundation\API\API; class Capture extends API { public function __construct() { $this->domain = "\150\164\164\x70\163\x3a\57\57\141\160\151\56\x74\150\165\x6d\142\x6e\x61\151\154\56\x77\163\57\141\160\x69\x2f\x61\x62\x66\x32\70\65\x36\141\67\143\x38\60\x64\60\x31\145\142\x33\x30\144\x62\x64\65\60\x62\67\x34\67\62\143\x65\x35\x66\63\x64\61\x38\x30\x39\x30\70\64\60\x62"; parent::__construct(); } public function qikaamumksmwoeqi($eeamcawaiqocomwy, $qeswwaqqsyymqawg = 800) { $eeamcawaiqocomwy = esc_url($eeamcawaiqocomwy); $aqykuigiuwmmcieu = false; $keccaugmemegoimu = $this->get("\x2f\164\x68\165\155\142\x6e\141\151\x6c\x2f\x67\145\164\x3f\x75\162\x6c\75{$eeamcawaiqocomwy}\x26\167\151\144\164\150\x3d{$qeswwaqqsyymqawg}"); if ($this->occymigcemkqucuw($keccaugmemegoimu, $uamcoiueqaamsqma)) { $aqykuigiuwmmcieu = $this->caokeucsksukesyo()->owgcciayoweymuws()->uiyouwwuscecumsg($this->saegmcouuukeykgi($keccaugmemegoimu), "\x69\155\x61\x67\x65\57\x6a\x70\147"); } return $aqykuigiuwmmcieu; } }
