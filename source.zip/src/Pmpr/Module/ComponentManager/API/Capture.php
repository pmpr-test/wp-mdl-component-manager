<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670d97f23fcc2             |
    |_______________________________________|
*/
 namespace Pmpr\Module\ComponentManager\API; use Pmpr\Common\Foundation\API\API; class Capture extends API { public function __construct() { $this->domain = "\150\164\x74\160\x73\x3a\x2f\x2f\141\160\x69\56\x74\150\x75\155\x62\x6e\x61\x69\154\56\x77\x73\57\141\160\x69\57\141\142\x66\x32\70\x35\x36\141\x37\143\x38\60\x64\x30\61\145\142\x33\60\x64\x62\144\65\x30\142\67\64\x37\x32\x63\x65\x35\146\x33\144\61\70\x30\71\x30\x38\64\60\x62"; parent::__construct(); } public function qikaamumksmwoeqi($eeamcawaiqocomwy, $qeswwaqqsyymqawg = 800) { $eeamcawaiqocomwy = esc_url($eeamcawaiqocomwy); $aqykuigiuwmmcieu = false; $keccaugmemegoimu = $this->get("\x2f\164\150\x75\155\x62\x6e\141\151\154\x2f\x67\x65\x74\x3f\x75\162\x6c\x3d{$eeamcawaiqocomwy}\x26\x77\x69\x64\164\x68\x3d{$qeswwaqqsyymqawg}"); if ($this->occymigcemkqucuw($keccaugmemegoimu, $uamcoiueqaamsqma)) { $aqykuigiuwmmcieu = $this->caokeucsksukesyo()->owgcciayoweymuws()->uiyouwwuscecumsg($this->saegmcouuukeykgi($keccaugmemegoimu), "\x69\x6d\x61\147\145\57\152\x70\x67"); } return $aqykuigiuwmmcieu; } }
