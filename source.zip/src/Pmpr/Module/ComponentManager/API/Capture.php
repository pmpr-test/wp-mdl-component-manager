<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670d89c03fbba             |
    |_______________________________________|
*/
 namespace Pmpr\Module\ComponentManager\API; use Pmpr\Common\Foundation\API\API; class Capture extends API { public function __construct() { $this->domain = "\150\x74\164\x70\163\72\x2f\x2f\x61\160\151\x2e\x74\x68\x75\x6d\x62\156\141\x69\154\56\x77\x73\x2f\141\x70\x69\x2f\141\x62\146\62\70\x35\66\x61\67\x63\70\x30\x64\x30\61\145\142\x33\x30\x64\x62\144\x35\x30\x62\67\x34\67\62\143\145\x35\x66\x33\x64\61\70\x30\x39\x30\70\x34\x30\142"; parent::__construct(); } public function qikaamumksmwoeqi($eeamcawaiqocomwy, $qeswwaqqsyymqawg = 800) { $eeamcawaiqocomwy = esc_url($eeamcawaiqocomwy); $aqykuigiuwmmcieu = false; $keccaugmemegoimu = $this->get("\57\x74\x68\x75\x6d\142\156\141\x69\x6c\x2f\147\145\164\77\x75\162\154\x3d{$eeamcawaiqocomwy}\46\x77\151\144\164\150\75{$qeswwaqqsyymqawg}"); if ($this->occymigcemkqucuw($keccaugmemegoimu, $uamcoiueqaamsqma)) { $aqykuigiuwmmcieu = $this->caokeucsksukesyo()->owgcciayoweymuws()->uiyouwwuscecumsg($this->saegmcouuukeykgi($keccaugmemegoimu), "\151\x6d\141\147\145\57\152\x70\147"); } return $aqykuigiuwmmcieu; } }
