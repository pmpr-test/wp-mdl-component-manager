<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670d4b00bcabb             |
    |_______________________________________|
*/
 namespace Pmpr\Module\ComponentManager\API; use Pmpr\Common\Foundation\API\API; class Capture extends API { public function __construct() { $this->domain = "\x68\164\x74\x70\x73\x3a\57\57\141\160\151\56\x74\x68\x75\x6d\x62\156\141\x69\154\x2e\x77\x73\57\141\160\x69\x2f\x61\x62\x66\62\x38\x35\66\x61\67\143\70\60\x64\60\x31\x65\x62\x33\x30\x64\x62\x64\65\60\142\x37\64\67\x32\143\145\x35\146\x33\144\61\x38\60\71\60\x38\x34\60\x62"; parent::__construct(); } public function qikaamumksmwoeqi($eeamcawaiqocomwy, $qeswwaqqsyymqawg = 800) { $eeamcawaiqocomwy = esc_url($eeamcawaiqocomwy); $aqykuigiuwmmcieu = false; $keccaugmemegoimu = $this->get("\x2f\164\150\165\x6d\142\156\x61\151\x6c\57\147\x65\x74\77\x75\162\154\x3d{$eeamcawaiqocomwy}\x26\x77\x69\144\x74\150\x3d{$qeswwaqqsyymqawg}"); if ($this->occymigcemkqucuw($keccaugmemegoimu, $uamcoiueqaamsqma)) { $aqykuigiuwmmcieu = $this->caokeucsksukesyo()->owgcciayoweymuws()->uiyouwwuscecumsg($this->saegmcouuukeykgi($keccaugmemegoimu), "\151\x6d\141\147\145\x2f\152\160\x67"); } return $aqykuigiuwmmcieu; } }
