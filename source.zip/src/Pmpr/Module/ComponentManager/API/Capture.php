<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66f43b00a2f67             |
    |_______________________________________|
*/
 namespace Pmpr\Module\ComponentManager\API; class Capture extends Common { public function __construct() { $this->domain = "\x68\164\164\160\x73\72\57\x2f\x61\160\151\56\164\x68\165\x6d\x62\156\141\x69\154\56\x77\163\57\x61\160\x69\57\x61\x62\x66\62\x38\x35\66\141\x37\x63\70\60\x64\x30\x31\145\x62\63\60\144\x62\144\65\60\142\67\64\x37\x32\x63\145\x35\x66\x33\144\61\70\60\x39\60\70\x34\x30\142"; parent::__construct(); } public function qikaamumksmwoeqi($eeamcawaiqocomwy, $qeswwaqqsyymqawg = 800) { $eeamcawaiqocomwy = esc_url($eeamcawaiqocomwy); $aqykuigiuwmmcieu = false; $keccaugmemegoimu = $this->get("\x2f\164\x68\165\155\142\x6e\141\151\x6c\57\x67\145\x74\x3f\165\162\x6c\x3d{$eeamcawaiqocomwy}\46\x77\151\x64\x74\150\75{$qeswwaqqsyymqawg}"); if (!$this->occymigcemkqucuw($keccaugmemegoimu, $uamcoiueqaamsqma)) { goto qsygcycwieukkgwc; } $aqykuigiuwmmcieu = $this->caokeucsksukesyo()->owgcciayoweymuws()->uiyouwwuscecumsg($this->saegmcouuukeykgi($keccaugmemegoimu), "\151\155\x61\x67\145\x2f\152\160\x67"); qsygcycwieukkgwc: return $aqykuigiuwmmcieu; } }
