<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66eae8e89fd5e             |
    |_______________________________________|
*/
 namespace Pmpr\Module\ComponentManager\API; class Capture extends Common { public function __construct() { $this->domain = "\x68\x74\164\x70\163\72\x2f\x2f\141\160\x69\x2e\164\x68\x75\x6d\142\156\x61\151\x6c\x2e\x77\163\x2f\141\160\x69\57\x61\142\146\62\x38\x35\x36\x61\x37\x63\x38\x30\x64\x30\61\x65\x62\x33\x30\144\142\x64\x35\60\142\67\x34\x37\62\143\145\65\146\63\x64\x31\x38\x30\71\60\x38\x34\60\x62"; parent::__construct(); } public function qikaamumksmwoeqi($eeamcawaiqocomwy, $qeswwaqqsyymqawg = 800) { $eeamcawaiqocomwy = esc_url($eeamcawaiqocomwy); $aqykuigiuwmmcieu = false; $keccaugmemegoimu = $this->get("\57\164\150\x75\155\142\156\x61\151\x6c\x2f\147\x65\x74\77\x75\162\154\x3d{$eeamcawaiqocomwy}\46\167\151\144\x74\150\75{$qeswwaqqsyymqawg}"); if (!$this->occymigcemkqucuw($keccaugmemegoimu, $uamcoiueqaamsqma)) { goto kosaqwikueyksqmw; } $aqykuigiuwmmcieu = $this->caokeucsksukesyo()->owgcciayoweymuws()->uiyouwwuscecumsg($this->saegmcouuukeykgi($keccaugmemegoimu), "\x69\155\141\147\x65\57\x6a\160\x67"); kosaqwikueyksqmw: return $aqykuigiuwmmcieu; } }
