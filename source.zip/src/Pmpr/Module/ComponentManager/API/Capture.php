<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670da379c4caa             |
    |_______________________________________|
*/
 namespace Pmpr\Module\ComponentManager\API; use Pmpr\Common\Foundation\API\API; class Capture extends API { public function __construct() { $this->domain = "\x68\164\x74\160\x73\x3a\57\57\x61\x70\151\x2e\x74\x68\x75\x6d\142\156\x61\151\154\x2e\167\163\x2f\x61\x70\x69\x2f\x61\142\146\x32\x38\65\66\x61\67\143\x38\60\144\60\x31\145\x62\63\60\x64\142\144\65\x30\142\x37\x34\67\x32\143\145\65\146\63\x64\x31\70\x30\71\x30\70\64\x30\142"; parent::__construct(); } public function qikaamumksmwoeqi($eeamcawaiqocomwy, $qeswwaqqsyymqawg = 800) { $eeamcawaiqocomwy = esc_url($eeamcawaiqocomwy); $aqykuigiuwmmcieu = false; $keccaugmemegoimu = $this->get("\x2f\164\150\165\x6d\x62\x6e\141\151\154\57\x67\145\x74\77\165\x72\x6c\75{$eeamcawaiqocomwy}\x26\x77\x69\144\164\150\x3d{$qeswwaqqsyymqawg}"); if ($this->occymigcemkqucuw($keccaugmemegoimu, $uamcoiueqaamsqma)) { $aqykuigiuwmmcieu = $this->caokeucsksukesyo()->owgcciayoweymuws()->uiyouwwuscecumsg($this->saegmcouuukeykgi($keccaugmemegoimu), "\x69\x6d\141\x67\145\x2f\152\x70\147"); } return $aqykuigiuwmmcieu; } }
