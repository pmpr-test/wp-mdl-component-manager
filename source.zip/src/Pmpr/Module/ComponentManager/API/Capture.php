<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66e5ec56484aa             |
    |_______________________________________|
*/
 namespace Pmpr\Module\ComponentManager\API; class Capture extends Common { public function __construct() { $this->domain = "\150\x74\x74\x70\x73\72\x2f\x2f\x61\x70\x69\56\x74\150\165\155\142\156\141\x69\x6c\56\x77\x73\x2f\141\160\x69\57\141\x62\146\62\x38\65\66\x61\67\x63\x38\60\x64\60\61\x65\x62\x33\60\144\x62\x64\65\x30\x62\67\64\x37\62\x63\x65\x35\x66\x33\144\61\70\x30\71\x30\70\x34\x30\x62"; parent::__construct(); } public function qikaamumksmwoeqi($eeamcawaiqocomwy, $qeswwaqqsyymqawg = 800) { $eeamcawaiqocomwy = esc_url($eeamcawaiqocomwy); $aqykuigiuwmmcieu = false; $keccaugmemegoimu = $this->get("\x2f\x74\x68\165\155\x62\x6e\141\x69\x6c\x2f\x67\x65\164\77\165\162\x6c\75{$eeamcawaiqocomwy}\x26\x77\151\144\164\150\75{$qeswwaqqsyymqawg}"); if (!$this->occymigcemkqucuw($keccaugmemegoimu, $uamcoiueqaamsqma)) { goto kosaqwikueyksqmw; } $aqykuigiuwmmcieu = $this->caokeucsksukesyo()->owgcciayoweymuws()->uiyouwwuscecumsg($this->saegmcouuukeykgi($keccaugmemegoimu), "\x69\155\141\x67\x65\x2f\152\160\147"); kosaqwikueyksqmw: return $aqykuigiuwmmcieu; } }
