<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66eae8e89fd5e             |
    |_______________________________________|
*/
 namespace Pmpr\Module\ComponentManager\API; class IPDetector extends Common { public function __construct() { $this->domain = "\150\164\x74\160\x3a\57\57\x69\x70\x2d\x61\160\x69\56\143\157\155\57\x6a\x73\x6f\156"; $this->ksiyskmggywgsayu("\146\151\145\154\144\x73", "\x31\x34\x37\64\x35\70"); parent::__construct(); } public function mcyaoicyesuysggi($kucumcusyyckayas) { $keccaugmemegoimu = $this->get("\57{$kucumcusyyckayas}"); $quscceoaiwasmkcy = false; if (!$this->occymigcemkqucuw($keccaugmemegoimu, $uamcoiueqaamsqma)) { goto mqkmcysgoiaouiwm; } $sogksuscggsicmac = $this->qemyqseaomicaacs($keccaugmemegoimu); if (!$sogksuscggsicmac) { goto ykomgumacooyomsk; } $quscceoaiwasmkcy = $this->caokeucsksukesyo()->ywqgcuymeiswqyqc()->get($sogksuscggsicmac, "\x63\x6f\x75\x6e\x74\x72\x79\103\157\144\x65"); ykomgumacooyomsk: mqkmcysgoiaouiwm: return $quscceoaiwasmkcy; } }
