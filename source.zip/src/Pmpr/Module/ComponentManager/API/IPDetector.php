<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670517593ad7e             |
    |_______________________________________|
*/
 namespace Pmpr\Module\ComponentManager\API; class IPDetector extends Common { public function __construct() { $this->domain = "\x68\164\x74\160\x3a\57\57\x69\160\x2d\141\x70\x69\x2e\143\x6f\x6d\x2f\152\x73\157\156"; $this->ksiyskmggywgsayu("\x66\151\145\154\x64\x73", "\x31\64\x37\x34\65\x38"); parent::__construct(); } public function mcyaoicyesuysggi($kucumcusyyckayas) { $keccaugmemegoimu = $this->get("\x2f{$kucumcusyyckayas}"); $quscceoaiwasmkcy = false; if (!$this->occymigcemkqucuw($keccaugmemegoimu, $uamcoiueqaamsqma)) { goto umgaesggesswoaqe; } $sogksuscggsicmac = $this->qemyqseaomicaacs($keccaugmemegoimu); if (!$sogksuscggsicmac) { goto wwkgkaecgiwggcck; } $quscceoaiwasmkcy = $this->caokeucsksukesyo()->ywqgcuymeiswqyqc()->get($sogksuscggsicmac, "\143\157\x75\x6e\164\162\x79\103\x6f\144\x65"); wwkgkaecgiwggcck: umgaesggesswoaqe: return $quscceoaiwasmkcy; } }
