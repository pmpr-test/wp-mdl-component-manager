<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66e5ec56484aa             |
    |_______________________________________|
*/
 namespace Pmpr\Module\ComponentManager\API; class IPDetector extends Common { public function __construct() { $this->domain = "\x68\164\x74\x70\72\x2f\x2f\x69\160\x2d\141\160\151\56\143\157\x6d\x2f\x6a\x73\157\x6e"; $this->ksiyskmggywgsayu("\x66\x69\145\154\144\x73", "\x31\x34\67\64\x35\x38"); parent::__construct(); } public function mcyaoicyesuysggi($kucumcusyyckayas) { $keccaugmemegoimu = $this->get("\57{$kucumcusyyckayas}"); $quscceoaiwasmkcy = false; if (!$this->occymigcemkqucuw($keccaugmemegoimu, $uamcoiueqaamsqma)) { goto mqkmcysgoiaouiwm; } $sogksuscggsicmac = $this->qemyqseaomicaacs($keccaugmemegoimu); if (!$sogksuscggsicmac) { goto ykomgumacooyomsk; } $quscceoaiwasmkcy = $this->caokeucsksukesyo()->ywqgcuymeiswqyqc()->get($sogksuscggsicmac, "\143\x6f\x75\156\164\x72\x79\103\157\x64\145"); ykomgumacooyomsk: mqkmcysgoiaouiwm: return $quscceoaiwasmkcy; } }
