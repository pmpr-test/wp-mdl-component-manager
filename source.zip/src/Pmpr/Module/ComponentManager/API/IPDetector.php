<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66f430fda8bb2             |
    |_______________________________________|
*/
 namespace Pmpr\Module\ComponentManager\API; class IPDetector extends Common { public function __construct() { $this->domain = "\150\x74\164\x70\x3a\x2f\x2f\x69\160\55\141\x70\x69\56\x63\x6f\x6d\57\x6a\x73\x6f\156"; $this->ksiyskmggywgsayu("\x66\x69\x65\154\x64\x73", "\x31\x34\67\64\65\x38"); parent::__construct(); } public function mcyaoicyesuysggi($kucumcusyyckayas) { $keccaugmemegoimu = $this->get("\x2f{$kucumcusyyckayas}"); $quscceoaiwasmkcy = false; if (!$this->occymigcemkqucuw($keccaugmemegoimu, $uamcoiueqaamsqma)) { goto quwcqmyokicssyew; } $sogksuscggsicmac = $this->qemyqseaomicaacs($keccaugmemegoimu); if (!$sogksuscggsicmac) { goto kiwqkcaekqqyuegq; } $quscceoaiwasmkcy = $this->caokeucsksukesyo()->ywqgcuymeiswqyqc()->get($sogksuscggsicmac, "\x63\x6f\x75\156\x74\162\x79\x43\157\144\145"); kiwqkcaekqqyuegq: quwcqmyokicssyew: return $quscceoaiwasmkcy; } }
