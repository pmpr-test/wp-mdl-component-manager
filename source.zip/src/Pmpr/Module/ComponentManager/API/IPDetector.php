<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             675f1d1141a85             |
    |_______________________________________|
*/
 namespace Pmpr\Module\ComponentManager\API; use Pmpr\Common\Foundation\API\API; class IPDetector extends API { public function __construct() { $this->domain = "\150\164\164\x70\72\x2f\57\151\160\x2d\141\x70\x69\x2e\x63\157\155\57\x6a\x73\157\156"; $this->ksiyskmggywgsayu("\x66\x69\x65\154\144\163", "\61\x34\67\x34\x35\x38"); parent::__construct(); } public function mcyaoicyesuysggi($kucumcusyyckayas) { $keccaugmemegoimu = $this->get("\x2f{$kucumcusyyckayas}"); $quscceoaiwasmkcy = false; if ($this->occymigcemkqucuw($keccaugmemegoimu, $uamcoiueqaamsqma)) { $sogksuscggsicmac = $this->qemyqseaomicaacs($keccaugmemegoimu); if ($sogksuscggsicmac) { $quscceoaiwasmkcy = $this->caokeucsksukesyo()->ywqgcuymeiswqyqc()->get($sogksuscggsicmac, "\x63\x6f\x75\156\164\162\171\103\x6f\x64\x65"); } } return $quscceoaiwasmkcy; } }
