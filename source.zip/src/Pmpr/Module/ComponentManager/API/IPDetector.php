<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66f43b00a2f67             |
    |_______________________________________|
*/
 namespace Pmpr\Module\ComponentManager\API; class IPDetector extends Common { public function __construct() { $this->domain = "\x68\164\x74\160\x3a\x2f\x2f\151\x70\55\141\x70\151\56\143\157\x6d\x2f\152\x73\x6f\x6e"; $this->ksiyskmggywgsayu("\146\151\145\154\x64\x73", "\x31\x34\67\64\x35\70"); parent::__construct(); } public function mcyaoicyesuysggi($kucumcusyyckayas) { $keccaugmemegoimu = $this->get("\57{$kucumcusyyckayas}"); $quscceoaiwasmkcy = false; if (!$this->occymigcemkqucuw($keccaugmemegoimu, $uamcoiueqaamsqma)) { goto quwcqmyokicssyew; } $sogksuscggsicmac = $this->qemyqseaomicaacs($keccaugmemegoimu); if (!$sogksuscggsicmac) { goto kiwqkcaekqqyuegq; } $quscceoaiwasmkcy = $this->caokeucsksukesyo()->ywqgcuymeiswqyqc()->get($sogksuscggsicmac, "\x63\x6f\165\x6e\x74\x72\171\x43\x6f\x64\x65"); kiwqkcaekqqyuegq: quwcqmyokicssyew: return $quscceoaiwasmkcy; } }
