<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             67235725ab938             |
    |_______________________________________|
*/
 namespace Pmpr\Module\ComponentManager\API; use Pmpr\Common\Foundation\API\API; class IPDetector extends API { public function __construct() { $this->domain = "\150\x74\x74\160\72\57\x2f\x69\x70\55\141\160\x69\56\143\157\155\x2f\152\163\157\x6e"; $this->ksiyskmggywgsayu("\x66\x69\145\x6c\144\x73", "\x31\64\67\x34\65\70"); parent::__construct(); } public function mcyaoicyesuysggi($kucumcusyyckayas) { $keccaugmemegoimu = $this->get("\57{$kucumcusyyckayas}"); $quscceoaiwasmkcy = false; if ($this->occymigcemkqucuw($keccaugmemegoimu, $uamcoiueqaamsqma)) { $sogksuscggsicmac = $this->qemyqseaomicaacs($keccaugmemegoimu); if ($sogksuscggsicmac) { $quscceoaiwasmkcy = $this->caokeucsksukesyo()->ywqgcuymeiswqyqc()->get($sogksuscggsicmac, "\143\157\x75\x6e\x74\162\x79\x43\157\x64\x65"); } } return $quscceoaiwasmkcy; } }
