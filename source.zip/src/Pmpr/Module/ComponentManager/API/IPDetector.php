<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6720b717ce967             |
    |_______________________________________|
*/
 namespace Pmpr\Module\ComponentManager\API; use Pmpr\Common\Foundation\API\API; class IPDetector extends API { public function __construct() { $this->domain = "\150\x74\x74\160\x3a\x2f\x2f\x69\x70\x2d\141\x70\x69\x2e\x63\x6f\155\57\x6a\163\157\156"; $this->ksiyskmggywgsayu("\146\x69\x65\x6c\x64\x73", "\x31\x34\x37\x34\65\70"); parent::__construct(); } public function mcyaoicyesuysggi($kucumcusyyckayas) { $keccaugmemegoimu = $this->get("\x2f{$kucumcusyyckayas}"); $quscceoaiwasmkcy = false; if ($this->occymigcemkqucuw($keccaugmemegoimu, $uamcoiueqaamsqma)) { $sogksuscggsicmac = $this->qemyqseaomicaacs($keccaugmemegoimu); if ($sogksuscggsicmac) { $quscceoaiwasmkcy = $this->caokeucsksukesyo()->ywqgcuymeiswqyqc()->get($sogksuscggsicmac, "\x63\157\165\x6e\164\x72\171\103\x6f\x64\145"); } } return $quscceoaiwasmkcy; } }
