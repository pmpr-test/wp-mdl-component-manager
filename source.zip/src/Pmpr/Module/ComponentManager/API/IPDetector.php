<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66e5e7901da8d             |
    |_______________________________________|
*/
 namespace Pmpr\Module\ComponentManager\API; class IPDetector extends Common { public function __construct() { $this->domain = "\150\164\x74\160\x3a\57\57\x69\x70\55\x61\160\x69\x2e\x63\x6f\155\57\x6a\x73\x6f\x6e"; $this->ksiyskmggywgsayu("\x66\151\145\x6c\144\x73", "\x31\x34\x37\64\x35\70"); parent::__construct(); } public function mcyaoicyesuysggi($kucumcusyyckayas) { $keccaugmemegoimu = $this->get("\x2f{$kucumcusyyckayas}"); $quscceoaiwasmkcy = false; if (!$this->occymigcemkqucuw($keccaugmemegoimu, $uamcoiueqaamsqma)) { goto mqkmcysgoiaouiwm; } $sogksuscggsicmac = $this->qemyqseaomicaacs($keccaugmemegoimu); if (!$sogksuscggsicmac) { goto ykomgumacooyomsk; } $quscceoaiwasmkcy = $this->caokeucsksukesyo()->ywqgcuymeiswqyqc()->get($sogksuscggsicmac, "\143\157\x75\x6e\x74\x72\171\x43\x6f\144\145"); ykomgumacooyomsk: mqkmcysgoiaouiwm: return $quscceoaiwasmkcy; } }
