<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670da318acac6             |
    |_______________________________________|
*/
 namespace Pmpr\Module\ComponentManager\API; use Pmpr\Common\Foundation\API\API; class IPDetector extends API { public function __construct() { $this->domain = "\x68\x74\164\x70\72\57\x2f\x69\160\x2d\141\x70\151\x2e\x63\157\155\57\152\x73\x6f\156"; $this->ksiyskmggywgsayu("\146\x69\x65\154\x64\163", "\61\64\67\x34\65\x38"); parent::__construct(); } public function mcyaoicyesuysggi($kucumcusyyckayas) { $keccaugmemegoimu = $this->get("\x2f{$kucumcusyyckayas}"); $quscceoaiwasmkcy = false; if ($this->occymigcemkqucuw($keccaugmemegoimu, $uamcoiueqaamsqma)) { $sogksuscggsicmac = $this->qemyqseaomicaacs($keccaugmemegoimu); if ($sogksuscggsicmac) { $quscceoaiwasmkcy = $this->caokeucsksukesyo()->ywqgcuymeiswqyqc()->get($sogksuscggsicmac, "\x63\x6f\x75\156\164\x72\171\x43\157\144\x65"); } } return $quscceoaiwasmkcy; } }
