<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             67705d837fe34             |
    |_______________________________________|
*/
 namespace Pmpr\Module\ComponentManager\API; use Pmpr\Common\Foundation\API\API; class IPDetector extends API { public function __construct() { $this->domain = "\150\x74\x74\160\x3a\x2f\x2f\x69\160\55\141\x70\151\x2e\x63\x6f\x6d\x2f\152\163\x6f\x6e"; $this->ksiyskmggywgsayu("\x66\x69\x65\154\x64\x73", "\x31\64\x37\x34\65\x38"); parent::__construct(); } public function mcyaoicyesuysggi($kucumcusyyckayas) { $keccaugmemegoimu = $this->get("\57{$kucumcusyyckayas}"); $quscceoaiwasmkcy = false; if ($this->occymigcemkqucuw($keccaugmemegoimu, $uamcoiueqaamsqma)) { $sogksuscggsicmac = $this->qemyqseaomicaacs($keccaugmemegoimu); if ($sogksuscggsicmac) { $quscceoaiwasmkcy = $this->caokeucsksukesyo()->ywqgcuymeiswqyqc()->get($sogksuscggsicmac, "\143\157\x75\156\x74\x72\x79\x43\157\144\145"); } } return $quscceoaiwasmkcy; } }
