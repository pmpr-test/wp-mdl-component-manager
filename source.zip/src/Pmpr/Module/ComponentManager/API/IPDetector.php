<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             672f20b43fd94             |
    |_______________________________________|
*/
 namespace Pmpr\Module\ComponentManager\API; use Pmpr\Common\Foundation\API\API; class IPDetector extends API { public function __construct() { $this->domain = "\150\164\x74\x70\72\x2f\57\151\160\55\x61\x70\x69\x2e\x63\157\155\57\x6a\x73\x6f\156"; $this->ksiyskmggywgsayu("\x66\x69\x65\154\144\163", "\61\64\x37\x34\x35\70"); parent::__construct(); } public function mcyaoicyesuysggi($kucumcusyyckayas) { $keccaugmemegoimu = $this->get("\x2f{$kucumcusyyckayas}"); $quscceoaiwasmkcy = false; if ($this->occymigcemkqucuw($keccaugmemegoimu, $uamcoiueqaamsqma)) { $sogksuscggsicmac = $this->qemyqseaomicaacs($keccaugmemegoimu); if ($sogksuscggsicmac) { $quscceoaiwasmkcy = $this->caokeucsksukesyo()->ywqgcuymeiswqyqc()->get($sogksuscggsicmac, "\x63\x6f\165\x6e\x74\x72\x79\x43\x6f\144\145"); } } return $quscceoaiwasmkcy; } }
