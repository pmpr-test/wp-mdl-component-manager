<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             678aa14f303c9             |
    |_______________________________________|
*/
 use Pmpr\Module\ComponentManager\ComponentManager; ComponentManager::symcgieuakksimmu();
