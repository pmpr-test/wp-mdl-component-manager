<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66f430fda8bb2             |
    |_______________________________________|
*/
 use Pmpr\Module\ComponentManager\ComponentManager; ComponentManager::symcgieuakksimmu();
